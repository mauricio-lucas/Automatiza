import io
import os
import sys
import zipfile
from cryptography.fernet import Fernet, InvalidToken

DIRETORIO_BACKUP = './backups'
DIRETORIO_RESTAURACAO = './dados_restaurados'
ARQUIVO_CHAVE = 'chave_secreta.key'


def carregar_chave():
    if not os.path.exists(ARQUIVO_CHAVE):
        raise FileNotFoundError(
            f"Chave '{ARQUIVO_CHAVE}' nao encontrada. Coloque-a no diretorio principal."
        )
    with open(ARQUIVO_CHAVE, 'rb') as file_chave:
        return file_chave.read()


def selecionar_backup(caminho_informado=None):
    if caminho_informado:
        if not os.path.exists(caminho_informado):
            raise FileNotFoundError(f"Arquivo de backup nao encontrado: {caminho_informado}")
        return caminho_informado

    if not os.path.exists(DIRETORIO_BACKUP):
        raise FileNotFoundError(f"Pasta '{DIRETORIO_BACKUP}' nao encontrada.")

    arquivos_enc = sorted(
        f for f in os.listdir(DIRETORIO_BACKUP) if f.endswith('.enc')
    )
    if not arquivos_enc:
        raise FileNotFoundError(f"Nenhum arquivo .enc encontrado em '{DIRETORIO_BACKUP}'.")

    return os.path.join(DIRETORIO_BACKUP, arquivos_enc[-1])


def restaurar_backup(caminho_backup=None):
    chave = carregar_chave()
    fernet = Fernet(chave)
    arquivo_enc = selecionar_backup(caminho_backup)

    print(f"[1] Lendo backup criptografado: {arquivo_enc}")
    with open(arquivo_enc, 'rb') as file:
        dados_criptografados = file.read()

    print("[2] Descriptografando os dados...")
    try:
        dados_zip = fernet.decrypt(dados_criptografados)
    except InvalidToken:
        print("[!] Erro: chave incorreta ou arquivo de backup corrompido.")
        sys.exit(1)

    os.makedirs(DIRETORIO_RESTAURACAO, exist_ok=True)
    print(f"[3] Extraindo arquivos para: {DIRETORIO_RESTAURACAO}")
    with zipfile.ZipFile(io.BytesIO(dados_zip), 'r') as zip_ref:
        zip_ref.extractall(DIRETORIO_RESTAURACAO)

    print("[4] Restauracao concluida com sucesso!")


if __name__ == "__main__":
    caminho = sys.argv[1] if len(sys.argv) > 1 else None
    restaurar_backup(caminho)
