# SecureBackup PME - Parauapebas

**Equipe:** Nicolas, Kevin, Kaio, David, Luiz Felipe
**Disciplina:** Cultura, Sociedade e Tecnologia
**Professor:** Prof. Keny Lucas

## Descrição do Projeto (MVP)
Como solução prática para a vulnerabilidade de pequenas e microempresas (PMEs) de Parauapebas aos ataques cibernéticos, desenvolvemos esta ferramenta de backup criptografado em Python. O objetivo é mitigar vazamentos de dados confidenciais e garantir a continuidade dos negócios locais.

## Como a ferramenta atua nas vulnerabilidades pesquisadas:
1. **Confidencialidade:** Utiliza criptografia simétrica (Fernet). Se dados da empresa vazarem por táticas de malwares ou ransomwares, os arquivos estarão completamente ilegíveis para os cibercriminosos.
2. **Disponibilidade e Automação:** Garante que a PME tenha uma cópia segura (backup) de seus dados financeiros, exigindo mínimo esforço técnico.
3. **Acessibilidade:** Combate o estigma de que cibersegurança é algo inacessível para microempresas, sendo executado com um único comando.

## Como executar a ferramenta:
1. Instale a dependência: `pip install cryptography`
2. Insira os arquivos que precisam de backup na pasta `dados_pme`.
3. Execute o script: `python3 secure_backup.py`
4. O arquivo protegido (.enc) será salvo na pasta `backups`. A `chave_secreta.key` será gerada no diretório principal e deve ser armazenada externamente de forma segura.

## Como descriptografar (restaurar backup):
1. Certifique-se de que a `chave_secreta.key` esteja no diretório principal do projeto.
2. Execute o script de restauração para descriptografar o backup mais recente:
   `python3 decrypt_backup.py`
3. Para restaurar um arquivo `.enc` específico, informe o caminho como argumento:
   `python3 decrypt_backup.py backups/backup_YYYYMMDD_HHMMSS.enc`
4. Os arquivos restaurados serão extraídos na pasta `dados_restaurados`.
