import os
import shutil
from datetime import datetime
from cryptography.fernet import Fernet

DIRETORIO_ORIGEM = './dados_pme'
DIRETORIO_BACKUP = './backups'
ARQUIVO_CHAVE = 'chave_secreta.key'

os.makedirs(DIRETORIO_BACKUP, exist_ok=True)

def gerar_ou_carregar_chave():
    if not os.path.exists(ARQUIVO_CHAVE):
        chave = Fernet.generate_key()
        with open(ARQUIVO_CHAVE, 'wb') as file_chave:
            file_chave.write(chave)
        print("[!] Nova chave de criptografia gerada e salva.")
        return chave
    else:
        with open(ARQUIVO_CHAVE, 'rb') as file_chave:
            return file_chave.read()

def realizar_backup():
    data_atual = datetime.now().strftime('%Y%m%d_%H%M%S')
    nome_arquivo_zip = f"{DIRETORIO_BACKUP}/backup_{data_atual}"
    
    print("[1] Compactando os dados das PMEs...")
    shutil.make_archive(nome_arquivo_zip, 'zip', DIRETORIO_ORIGEM)
    caminho_zip = f"{nome_arquivo_zip}.zip"
    
    print("[2] Criptografando o backup")
    chave = gerar_ou_carregar_chave()
    fernet = Fernet(chave)
    
    with open(caminho_zip, 'rb') as file:
        dados_originais = file.read()
        
    dados_criptografados = fernet.encrypt(dados_originais)
    
    arquivo_final = f"{nome_arquivo_zip}.enc"
    with open(arquivo_final, 'wb') as file:
        file.write(dados_criptografados)
        
    os.remove(caminho_zip)
    
    print(f"[3] Backup concluido com sucesso. Arquivo salvo em: {arquivo_final}")

if __name__ == "__main__":
    realizar_backup()
